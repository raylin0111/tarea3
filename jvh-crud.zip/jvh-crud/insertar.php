<?php
include("conexion.php");
$con=conectar();

$codigo=$_POST['codigo'];
$nombre=$_POST['Nombre'];
$apellido=$_POST['Apellido'];
$email=$_POST['email'];

$sql="INSERT INTO conctato VALUES('$codigo','$nombre','$apellido','$email')";
$query= mysqli_query($con,$sql);

if($query){
   header("location: usuariosd.php");

}else{

}
?>