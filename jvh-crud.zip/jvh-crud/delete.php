<?php

include("conexion.php");
$con=conectar();

$codigo=$_GET['id'];


$sql="DELETE FROM conctato WHERE codigo='$codigo'";
$query= mysqli_query($con,$sql);

if($query){
   header("location: usuariosd.php");

}